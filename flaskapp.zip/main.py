from flask import Flask
from flask import request, escape

from converter import fahrenheit_from, inches_from

app = Flask(__name__)


@app.route("/")
def index():
    celsius = request.args.get("celsius", "")
    centimeters = request.args.get("centimeters", "")
    if celsius:
        fahrenheit = fahrenheit_from(celsius)
    else:
        fahrenheit = ""
    if centimeters:
        inches = inches_from(centimeters)
    else:
        inches = ""
    return (
        """<form action="" method="get">
                Celsius temperature: <input type="text" name="celsius">
                <input type="submit" value="Convert to Fahrenheit">
            </form>"""
        + "Fahrenheit: "
        + fahrenheit
        + """<form action="" method="get">
                Lengh in centimeters: <input type="text" name="centimeters">
                <input type="submit" value="Convert to inches">
            </form>"""
        + "Inches: "
        + inches
    )


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8080, debug=True)
